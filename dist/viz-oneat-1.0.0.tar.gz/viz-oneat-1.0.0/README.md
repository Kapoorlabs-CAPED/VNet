# VNet
Visualize activations of any neural network in Napari
